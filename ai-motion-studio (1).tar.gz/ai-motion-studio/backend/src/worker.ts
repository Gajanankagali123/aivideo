import { Worker, Job } from 'bullmq';
import fs from 'fs';
import path from 'path';
import { connection, GenerationJobData } from './lib/queue';
import { pool } from './lib/db';
import { logger } from './lib/logger';
import { storage } from './lib/storage';
import { commitCredits, refundCredits } from './services/creditService';
import { getVideoProvider, getVoiceProvider, getAvatarProvider } from './providers/registry';

async function updateJob(jobId: string, fields: Record<string, any>) {
  const keys = Object.keys(fields);
  const setClause = keys.map((k, i) => `"${k}"=$${i + 2}`).join(', ');
  await pool.query(`UPDATE "VideoGenerationJob" SET ${setClause} WHERE id=$1`, [jobId, ...keys.map((k) => fields[k])]);
}

async function processJob(bullJob: Job<GenerationJobData>) {
  const { jobId } = bullJob.data;
  const jobRes = await pool.query('SELECT * FROM "VideoGenerationJob" WHERE id=$1', [jobId]);
  const job = jobRes.rows[0];
  if (!job) {
    logger.warn({ jobId }, 'Job row not found, skipping');
    return;
  }
  if (job.status === 'canceled') {
    logger.info({ jobId }, 'Job was canceled before processing started, skipping');
    return;
  }

  await updateJob(jobId, { status: 'processing', stage: 'ANALYZING PROMPT', startedAt: new Date() });
  logger.info({ jobId, type: job.type }, 'Worker picked up job');

  const onProgress = async (pct: number, stage: string) => {
    await updateJob(jobId, { progress: pct, stage });
    await bullJob.updateProgress(pct);
  };

  try {
    const input = job.input;
    let result;

    if (job.type === 'text-to-video' || job.type === 'image-to-video' || job.type === 'script-to-video') {
      const provider = getVideoProvider();
      result = await provider.generateVideo(
        {
          prompt: input.prompt || input.script || input.motionPrompt || job.type,
          style: input.style,
          aspectRatio: input.aspectRatio,
          durationSec: job.durationSec || input.duration || 10,
          resolution: job.resolution || input.resolution || '1080p',
          cameraMovement: input.cameraMovement,
          visualStyle: input.visualStyle,
          motionStrength: input.motionStrength,
          creativity: input.creativity,
        },
        onProgress
      );
    } else if (job.type === 'avatar-video') {
      const provider = getAvatarProvider();
      result = await provider.generateAvatarVideo(
        { avatarName: input.avatarName || 'AI Avatar', script: input.script || '', language: input.language, voiceName: input.voiceName },
        onProgress
      );
    } else if (job.type === 'voiceover') {
      const provider = getVoiceProvider();
      result = await provider.generateVoice(
        { text: input.text || '', language: input.language, accent: input.accent, speed: input.speed, pitch: input.pitch, emotion: input.emotion, voiceName: input.voiceName },
        onProgress
      );
    } else {
      throw new Error(`Unknown job type: ${job.type}`);
    }

    // Move rendered file into storage and record a MediaAsset row.
    const ext = result.mimeType === 'audio/wav' ? 'wav' : 'mp4';
    const storageKey = `renders/${job.userId}/${jobId}.${ext}`;
    const buffer = fs.readFileSync(result.filePath);
    await storage.put(storageKey, buffer);
    fs.unlink(result.filePath, () => {});

    const assetRes = await pool.query(
      `INSERT INTO "MediaAsset" (id,"userId","projectId",type,filename,"storageKey","mimeType","sizeBytes","durationSec")
       VALUES (gen_random_uuid(),$1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [job.userId, job.projectId, ext === 'wav' ? 'audio' : 'video', path.basename(storageKey), storageKey, result.mimeType, buffer.length, result.durationSec ?? null]
    );
    const asset = assetRes.rows[0];

    await updateJob(jobId, { status: 'completed', stage: 'FINALIZING YOUR CREATION', progress: 100, resultAssetId: asset.id, completedAt: new Date() });
    await pool.query('UPDATE "Project" SET status=$1 WHERE id=$2', ['ready', job.projectId]);
    await commitCredits(job.userId, job.creditsReserved, `Generation job ${jobId} completed`, jobId);

    await pool.query(
      `INSERT INTO "Notification" (id,"userId",title,body) VALUES (gen_random_uuid(),$1,$2,$3)`,
      [job.userId, 'Your video is ready', `"${job.type}" finished rendering and is ready to view.`]
    );

    logger.info({ jobId, assetId: asset.id }, 'Job completed successfully');
  } catch (err: any) {
    logger.error({ jobId, err: err.message }, 'Job failed, refunding credits');
    await updateJob(jobId, { status: 'failed', stage: 'FAILED', error: err.message, completedAt: new Date() });
    await pool.query('UPDATE "Project" SET status=$1 WHERE id=$2', ['failed', job.projectId]);
    await refundCredits(job.userId, job.creditsReserved, `Generation job ${jobId} failed: ${err.message}`, jobId);
    throw err; // let BullMQ record the failure too
  }
}

const worker = new Worker<GenerationJobData>('video-generation', processJob, { connection, concurrency: 2 });

worker.on('completed', (job) => logger.info({ id: job.id }, 'BullMQ job completed'));
worker.on('failed', (job, err) => logger.error({ id: job?.id, err: err.message }, 'BullMQ job failed'));

logger.info('Worker started, listening on queue "video-generation"');
