import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app';

function uniqueEmail() {
  return `gen-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
}

async function registeredAgent() {
  const email = uniqueEmail();
  const agent = request.agent(app);
  await agent.post('/api/auth/register').send({ name: 'Gen Test', email, password: 'password123' });
  return agent;
}

async function waitForJob(agent: any, jobId: string, timeoutMs = 20000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await agent.get(`/api/generations/jobs/${jobId}`);
    if (['completed', 'failed', 'canceled'].includes(res.body.data.status)) return res.body.data;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error('Test timed out waiting for job to finish');
}

describe('Generation pipeline (real worker + real FFmpeg)', () => {
  it('runs a text-to-video job to completion and produces a downloadable asset', async () => {
    const agent = await registeredAgent();
    const create = await agent.post('/api/generations/text-to-video').send({
      prompt: 'integration test render',
      duration: 5,
      resolution: '720p',
    });
    expect(create.status).toBe(201);

    const job = await waitForJob(agent, create.body.data.jobId);
    expect(job.status).toBe('completed');
    expect(job.resultAssetId).toBeTruthy();

    const dl = await agent.get(`/api/assets/${job.resultAssetId}/download-url`);
    expect(dl.status).toBe(200);
    expect(dl.body.data.url).toContain('/api/files/');
  }, 25000);

  it('commits reserved credits (not double-charged) once a job completes', async () => {
    const agent = await registeredAgent();
    const create = await agent.post('/api/generations/text-to-video').send({ prompt: 'commit test', duration: 5, resolution: '720p' });
    const cost = create.body.data.creditsReserved;

    await waitForJob(agent, create.body.data.jobId);

    const balance = await agent.get('/api/credits/balance');
    expect(balance.body.data.reserved).toBe(0);
    expect(balance.body.data.balance).toBe(15 - cost);
  }, 25000);

  it('rejects access to a job that belongs to another user', async () => {
    const agentA = await registeredAgent();
    const agentB = await registeredAgent();
    const create = await agentA.post('/api/generations/text-to-video').send({ prompt: 'ownership test', duration: 5, resolution: '720p' });

    const res = await agentB.get(`/api/generations/jobs/${create.body.data.jobId}`);
    expect(res.status).toBe(403);
  });

  it('refunds credits when a job is canceled', async () => {
    const agent = await registeredAgent();
    const create = await agent.post('/api/generations/text-to-video').send({ prompt: 'cancel test', duration: 5, resolution: '720p' });
    expect(create.status).toBe(201);
    // Immediately try to cancel — may race with the worker, but either path (queued cancel or
    // "already completed") must never leave credits stuck in limbo.
    const cancel = await agent.post(`/api/generations/jobs/${create.body.data.jobId}/cancel`);
    expect([200, 400]).toContain(cancel.status);

    if (cancel.status === 200) {
      const balance = await agent.get('/api/credits/balance');
      expect(balance.body.data.reserved).toBe(0);
      expect(balance.body.data.balance).toBe(15); // fully refunded
    }
  }, 15000);
});
