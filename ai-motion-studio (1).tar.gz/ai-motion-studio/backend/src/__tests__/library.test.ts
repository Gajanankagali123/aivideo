import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app';

function uniqueEmail() {
  return `lib-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
}
async function registeredAgent() {
  const email = uniqueEmail();
  const agent = request.agent(app);
  await agent.post('/api/auth/register').send({ name: 'Lib Test', email, password: 'password123' });
  return agent;
}

describe('Public reference data', () => {
  it('lists seeded plans without auth', async () => {
    const res = await request(app).get('/api/plans');
    expect(res.status).toBe(200);
    const keys = res.body.data.plans.map((p: any) => p.key);
    expect(keys).toEqual(expect.arrayContaining(['free', 'creator', 'pro']));
  });

  it('lists seeded templates and filters by category', async () => {
    const all = await request(app).get('/api/templates');
    expect(all.body.data.templates.length).toBeGreaterThan(0);
    const filtered = await request(app).get('/api/templates?category=YouTube');
    expect(filtered.body.data.templates.every((t: any) => t.category === 'YouTube')).toBe(true);
  });
});

describe('Avatars and voices require auth', () => {
  it('rejects unauthenticated avatar/voice list requests', async () => {
    const a = await request(app).get('/api/avatars');
    const v = await request(app).get('/api/voices');
    expect(a.status).toBe(401);
    expect(v.status).toBe(401);
  });

  it('returns seeded system avatars and voices with real sample audio keys for an authed user', async () => {
    const agent = await registeredAgent();
    const avatars = await agent.get('/api/avatars');
    expect(avatars.body.data.avatars.length).toBeGreaterThan(0);

    const voices = await agent.get('/api/voices');
    expect(voices.body.data.voices.length).toBeGreaterThan(0);
    expect(voices.body.data.voices[0].previewUrl).toContain('/api/files/voice-samples');
  });
});

describe('Project ownership isolation', () => {
  it('user B cannot read, rename, or delete user A project', async () => {
    const a = await registeredAgent();
    const b = await registeredAgent();
    const create = await a.post('/api/generations/text-to-video').send({ prompt: 'isolation test', duration: 5, resolution: '720p' });
    const projectId = create.body.data.projectId;

    const readRes = await b.get(`/api/projects/${projectId}`);
    expect(readRes.status).toBe(403);

    const renameRes = await b.patch(`/api/projects/${projectId}`).send({ title: 'hijacked' });
    expect(renameRes.status).toBe(403);

    const deleteRes = await b.delete(`/api/projects/${projectId}`);
    expect(deleteRes.status).toBe(403);
  });
});
