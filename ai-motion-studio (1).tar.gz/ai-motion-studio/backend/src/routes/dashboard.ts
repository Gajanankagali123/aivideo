import { Router } from 'express';
import { pool } from '../lib/db';
import { ok } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';

const router = Router();
router.use(requireAuth);

router.get('/summary', asyncHandler(async (req, res) => {
  const userId = req.userId;

  const [videosTotal, videosWeek, wallet, storageAgg, sub, recent] = await Promise.all([
    pool.query(`SELECT COUNT(*)::int AS n FROM "VideoGenerationJob" WHERE "userId"=$1 AND status='completed'`, [userId]),
    pool.query(`SELECT COUNT(*)::int AS n FROM "VideoGenerationJob" WHERE "userId"=$1 AND status='completed' AND "completedAt" > now() - interval '7 days'`, [userId]),
    pool.query(`SELECT * FROM "CreditWallet" WHERE "userId"=$1`, [userId]),
    pool.query(`SELECT COALESCE(SUM("sizeBytes"),0)::bigint AS bytes FROM "MediaAsset" WHERE "userId"=$1`, [userId]),
    pool.query(
      `SELECT s.*, p.key AS "planKey", p.name AS "planName" FROM "Subscription" s JOIN "Plan" p ON p.id=s."planId" WHERE s."userId"=$1`,
      [userId]
    ),
    pool.query(
      `SELECT id, title, type, status, "durationSec", resolution, "createdAt", "updatedAt"
       FROM "Project" WHERE "userId"=$1 AND "deletedAt" IS NULL ORDER BY "updatedAt" DESC LIMIT 8`,
      [userId]
    ),
  ]);

  const storageBytes = Number(storageAgg.rows[0]?.bytes || 0);

  ok(res, {
    videosGenerated: videosTotal.rows[0].n,
    videosThisWeek: videosWeek.rows[0].n,
    credits: wallet.rows[0]?.balance ?? 0,
    creditsReserved: wallet.rows[0]?.reserved ?? 0,
    storageUsedMb: Math.round((storageBytes / 1024 / 1024) * 10) / 10,
    storageLimitMb: 50 * 1024,
    plan: sub.rows[0] ? { key: sub.rows[0].planKey, name: sub.rows[0].planName, renewsAt: sub.rows[0].currentPeriodEnd } : null,
    recentProjects: recent.rows,
  });
}));

export default router;
