import { spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { v4 as uuid } from 'uuid';
import { VideoProvider, VoiceProvider, AvatarProvider, VideoGenParams, VoiceGenParams, AvatarGenParams, GenResult } from './types';

/**
 * MockProvider — used when VIDEO_PROVIDER / VOICE_PROVIDER / AVATAR_PROVIDER = "mock" (the default).
 * This does NOT fake a success response: it actually invokes FFmpeg and produces a real,
 * playable MP4/WAV file on disk. The *content* is a placeholder (gradient + burned-in prompt
 * text, or a tone for audio) because no real generative model is wired up — but the file,
 * the render pipeline, the progress callbacks, and the job lifecycle are all real.
 *
 * To go live: implement a class satisfying the same interface (e.g. RunwayVideoProvider)
 * in this folder, and select it in providerRegistry.ts based on config.providers.*.name.
 */

function run(cmd: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stderr = '';
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${cmd} exited ${code}: ${stderr.slice(-800)}`));
    });
    proc.on('error', reject);
  });
}

const PALETTES = [
  ['0x1a0a12', '0xff3d63'],
  ['0x0a0e1a', '0x4d8dff'],
  ['0x140a1a', '0x8b5cf6'],
];

function escapeDrawtext(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/:/g, '\\:').replace(/'/g, "\\'").slice(0, 90);
}

async function renderPlaceholderVideo(
  label: string,
  durationSec: number,
  resolution: string,
  onProgress: (pct: number, stage: string) => void
): Promise<GenResult> {
  const [c1, c2] = PALETTES[Math.floor(Math.random() * PALETTES.length)];
  const dims: Record<string, string> = { '720p': '1280x720', '1080p': '1920x1080', '4k': '3840x2160' };
  const size = dims[resolution.toLowerCase()] || '1920x1080';
  const outPath = path.join(os.tmpdir(), `ams-render-${uuid()}.mp4`);
  const font = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';
  const text = escapeDrawtext(label);

  const stages: [number, string][] = [
    [10, 'ANALYZING PROMPT'],
    [25, 'GENERATING SCENES'],
    [45, 'CREATING VISUALS'],
    [65, 'ADDING MOTION'],
    [85, 'RENDERING VIDEO'],
  ];
  for (const [pct, stage] of stages) {
    onProgress(pct, stage);
    await new Promise((r) => setTimeout(r, 250 + Math.random() * 250));
  }

  const [w, h] = size.split('x');
  const drawFilter = `drawtext=fontfile=${font}:text='${text}':fontcolor=white:fontsize=${Math.round(parseInt(w) / 28)}:x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=black@0.35:boxborderw=20`;

  await run('ffmpeg', [
    '-y',
    '-f', 'lavfi', '-i', `gradients=s=${size}:d=${durationSec}:c0=${c1}:c1=${c2}:x0=0:y0=0:x1=${w}:y1=${h}:speed=0.02`,
    '-vf', drawFilter,
    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-t', String(durationSec),
    outPath,
  ]);

  onProgress(97, 'FINALIZING YOUR CREATION');
  return { filePath: outPath, mimeType: 'video/mp4', durationSec };
}

export class MockVideoProvider implements VideoProvider {
  name = 'mock';
  isConfigured() {
    return true;
  }
  async generateVideo(params: VideoGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult> {
    const label = `${params.style || 'Cinematic'} — ${params.prompt.slice(0, 60)}`;
    return renderPlaceholderVideo(label, params.durationSec, params.resolution, onProgress);
  }
}

export class MockAvatarProvider implements AvatarProvider {
  name = 'mock';
  isConfigured() {
    return true;
  }
  async generateAvatarVideo(params: AvatarGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult> {
    const label = `${params.avatarName} — "${params.script.slice(0, 50)}"`;
    return renderPlaceholderVideo(label, 10, '1080p', onProgress);
  }
}

export class MockVoiceProvider implements VoiceProvider {
  name = 'mock';
  isConfigured() {
    return true;
  }
  async generateVoice(params: VoiceGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult> {
    onProgress(20, 'ANALYZING PROMPT');
    await new Promise((r) => setTimeout(r, 300));
    onProgress(55, 'RENDERING VIDEO');
    const outPath = path.join(os.tmpdir(), `ams-voice-${uuid()}.wav`);
    // Real audio file: a tone whose duration scales with text length, as a stand-in for real TTS.
    const seconds = Math.max(2, Math.min(20, Math.round(params.text.length / 14)));
    const freq = 220 + ((params.pitch ?? 50) / 100) * 220;
    await run('ffmpeg', [
      '-y',
      '-f', 'lavfi', '-i', `sine=frequency=${freq}:duration=${seconds}`,
      '-af', 'afade=t=in:d=0.3,afade=t=out:st=' + (seconds - 0.3) + ':d=0.3',
      outPath,
    ]);
    onProgress(95, 'FINALIZING YOUR CREATION');
    return { filePath: outPath, mimeType: 'audio/wav', durationSec: seconds };
  }
}
