import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import { hashPassword, verifyPassword, ACCESS_COOKIE, REFRESH_COOKIE } from '../lib/auth';

const router = Router();
router.use(requireAuth);

router.patch('/me', asyncHandler(async (req, res) => {
  const parsed = z.object({ name: z.string().min(1).max(120).optional(), email: z.string().email().optional() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);
  const { name, email } = parsed.data;

  if (email) {
    const clash = await pool.query('SELECT id FROM "User" WHERE email=$1 AND id<>$2', [email.toLowerCase(), req.userId]);
    if (clash.rows[0]) throw new ApiError(409, 'EMAIL_TAKEN', 'That email is already in use.');
  }

  const res2 = await pool.query(
    `UPDATE "User" SET name=COALESCE($1,name), email=COALESCE($2,email), "updatedAt"=now() WHERE id=$3 RETURNING *`,
    [name ?? null, email ? email.toLowerCase() : null, req.userId]
  );
  const u = res2.rows[0];
  ok(res, { user: { id: u.id, name: u.name, email: u.email } });
}));

router.patch('/me/password', asyncHandler(async (req, res) => {
  const parsed = z.object({ currentPassword: z.string().min(1), newPassword: z.string().min(8) }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);

  const userRes = await pool.query('SELECT * FROM "User" WHERE id=$1', [req.userId]);
  const user = userRes.rows[0];
  const validPw = await verifyPassword(parsed.data.currentPassword, user.passwordHash);
  if (!validPw) throw new ApiError(401, 'INVALID_CREDENTIALS', 'Current password is incorrect.');

  const hash = await hashPassword(parsed.data.newPassword);
  await pool.query('UPDATE "User" SET "passwordHash"=$1, "updatedAt"=now() WHERE id=$2', [hash, req.userId]);
  await pool.query('UPDATE "Session" SET "revokedAt"=now() WHERE "userId"=$1', [req.userId]);
  ok(res, { success: true });
}));

router.patch('/me/settings', asyncHandler(async (req, res) => {
  const parsed = z.object({
    emailNotifications: z.boolean().optional(),
    productUpdates: z.boolean().optional(),
    language: z.string().optional(),
  }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);
  const { emailNotifications, productUpdates, language } = parsed.data;
  const r = await pool.query(
    `UPDATE "UserSettings" SET
      "emailNotifications"=COALESCE($1,"emailNotifications"),
      "productUpdates"=COALESCE($2,"productUpdates"),
      language=COALESCE($3,language),
      "updatedAt"=now()
     WHERE "userId"=$4 RETURNING *`,
    [emailNotifications ?? null, productUpdates ?? null, language ?? null, req.userId]
  );
  ok(res, { settings: r.rows[0] });
}));

router.delete('/me', asyncHandler(async (req, res) => {
  await pool.query('UPDATE "User" SET "deletedAt"=now(), email = email || \'.deleted.\' || id WHERE id=$1', [req.userId]);
  await pool.query('UPDATE "Session" SET "revokedAt"=now() WHERE "userId"=$1', [req.userId]);
  res.clearCookie(ACCESS_COOKIE, { path: '/' });
  res.clearCookie(REFRESH_COOKIE, { path: '/' });
  ok(res, { success: true });
}));

export default router;
