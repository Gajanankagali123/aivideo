import { spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { pool } from '../src/lib/db';
import { storage } from '../src/lib/storage';

function run(cmd: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stderr = '';
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => (code === 0 ? resolve() : reject(new Error(stderr.slice(-500)))));
    proc.on('error', reject);
  });
}

async function seedPlans() {
  const plans = [
    { key: 'free', name: 'Free', monthlyCredits: 15, maxResolution: '720p', watermark: true, priceCents: 0, features: ['15 credits / month', '720p export', 'Watermarked videos', 'Limited templates'] },
    { key: 'creator', name: 'Creator', monthlyCredits: 300, maxResolution: '1080p', watermark: false, priceCents: 2900, features: ['300 credits / month', '1080p export', 'No watermark', 'Premium AI models', 'AI voice generation'] },
    { key: 'pro', name: 'Pro', monthlyCredits: 1000, maxResolution: '4K', watermark: false, priceCents: 7900, features: ['1000 credits / month', '4K export', 'Priority rendering', 'Advanced AI models', 'Commercial usage rights', 'Unlimited projects'] },
  ];
  for (const p of plans) {
    await pool.query(
      `INSERT INTO "Plan" (id,key,name,"monthlyCredits","maxResolution",watermark,"priceCents",currency,features)
       VALUES (gen_random_uuid(),$1,$2,$3,$4,$5,$6,'usd',$7)
       ON CONFLICT (key) DO UPDATE SET name=$2,"monthlyCredits"=$3,"maxResolution"=$4,watermark=$5,"priceCents"=$6,features=$7`,
      [p.key, p.name, p.monthlyCredits, p.maxResolution, p.watermark, p.priceCents, JSON.stringify(p.features)]
    );
  }
  console.log(`Seeded ${plans.length} plans`);
}

async function seedTemplates() {
  const templates: [string, string][] = [
    ['Cinematic Product Reveal', 'Product Videos'], ['YouTube Intro Loop', 'YouTube'], ['Reel Trend — Quick Cuts', 'Instagram Reels'],
    ['Real Estate Walkthrough', 'Real Estate'], ['Startup Pitch Opener', 'Business'], ['TikTok Hook Template', 'TikTok'],
    ['Course Lesson Intro', 'Education'], ['Festive Sale Promo', 'Advertisements'], ['Drone City Establishing', 'Cinematic'],
    ['Testimonial Overlay', 'Business'], ['Social Countdown', 'Social Media'], ['App Feature Walkthrough', 'Product Videos'],
  ];
  const existing = await pool.query('SELECT COUNT(*)::int AS n FROM "Template"');
  if (existing.rows[0].n > 0) { console.log('Templates already seeded, skipping'); return; }
  let i = 0;
  for (const [title, category] of templates) {
    const prefill = { style: category === 'Cinematic' ? 'Cinematic' : 'Commercial', aspectRatio: category === 'Instagram Reels' || category === 'TikTok' ? '9:16' : '16:9', duration: 10, resolution: '1080p', prompt: `${title} — a ${category.toLowerCase()} style video.` };
    await pool.query(
      `INSERT INTO "Template" (id,title,category,prefill,"thumbSeed") VALUES (gen_random_uuid(),$1,$2,$3,$4)`,
      [title, category, JSON.stringify(prefill), i++]
    );
  }
  console.log(`Seeded ${templates.length} templates`);
}

async function seedAvatars() {
  const existing = await pool.query('SELECT COUNT(*)::int AS n FROM "Avatar" WHERE "userId" IS NULL');
  if (existing.rows[0].n > 0) { console.log('Avatars already seeded, skipping'); return; }
  const names = ['Aria', 'Kabir', 'Meera', 'Rohan', 'Ishaan', 'Nova'];
  for (const name of names) {
    await pool.query(`INSERT INTO "Avatar" (id,"userId",name,"isCustom") VALUES (gen_random_uuid(),NULL,$1,false)`, [name]);
  }
  console.log(`Seeded ${names.length} system avatars`);
}

async function seedVoicesWithSamples() {
  const existing = await pool.query('SELECT COUNT(*)::int AS n FROM "Voice"');
  if (existing.rows[0].n > 0) { console.log('Voices already seeded, skipping'); return; }
  const voices: [string, string, string, string, number][] = [
    ['Aria', 'Warm, Female', 'en', 'female', 240],
    ['Kabir', 'Bold, Male', 'en', 'male', 160],
    ['Meera', 'Calm, Female', 'en', 'female', 210],
    ['Dev', 'Energetic, Male', 'en', 'male', 190],
    ['Sana', 'Editorial, Female', 'en', 'female', 260],
  ];
  for (const [name, description, language, gender, freq] of voices) {
    const tmp = path.join(os.tmpdir(), `voice-sample-${name}.wav`);
    await run('ffmpeg', ['-y', '-f', 'lavfi', '-i', `sine=frequency=${freq}:duration=2`, '-af', 'afade=t=in:d=0.2,afade=t=out:st=1.8:d=0.2', tmp]);
    const buf = fs.readFileSync(tmp);
    const key = `voice-samples/${name.toLowerCase()}.wav`;
    await storage.put(key, buf);
    fs.unlinkSync(tmp);
    await pool.query(
      `INSERT INTO "Voice" (id,name,description,language,gender,"sampleKey") VALUES (gen_random_uuid(),$1,$2,$3,$4,$5)`,
      [name, description, language, gender, key]
    );
  }
  console.log(`Seeded ${voices.length} voices with real sample audio`);
}

async function main() {
  await seedPlans();
  await seedTemplates();
  await seedAvatars();
  await seedVoicesWithSamples();
  await pool.end();
  console.log('Seed complete.');
}

main().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
