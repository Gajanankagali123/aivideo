import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { config } from './config';

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}
export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export interface AccessTokenPayload {
  sub: string; // userId
  email: string;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, config.jwt.accessSecret, { expiresIn: config.jwt.accessTtl as any });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, config.jwt.accessSecret) as AccessTokenPayload;
}

export function signRefreshToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, config.jwt.refreshSecret, { expiresIn: `${config.jwt.refreshTtlDays}d` });
}

export function verifyRefreshToken(token: string): AccessTokenPayload {
  return jwt.verify(token, config.jwt.refreshSecret) as AccessTokenPayload;
}

export const ACCESS_COOKIE = 'ams_access';
export const REFRESH_COOKIE = 'ams_refresh';

export function cookieOptions(maxAgeMs: number) {
  return {
    httpOnly: true,
    secure: config.cookieSecure,
    sameSite: 'lax' as const,
    maxAge: maxAgeMs,
    path: '/',
  };
}
