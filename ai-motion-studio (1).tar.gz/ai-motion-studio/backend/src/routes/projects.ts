import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';

const router = Router();
router.use(requireAuth);

async function loadOwnedProject(userId: string, id: string) {
  const r = await pool.query('SELECT * FROM "Project" WHERE id=$1 AND "deletedAt" IS NULL', [id]);
  const project = r.rows[0];
  if (!project) throw new ApiError(404, 'NOT_FOUND', 'Project not found.');
  if (project.userId !== userId) throw new ApiError(403, 'FORBIDDEN', 'You do not have access to this project.');
  return project;
}

router.get('/', asyncHandler(async (req, res) => {
  const search = (req.query.search as string) || '';
  const status = (req.query.status as string) || '';
  const params: any[] = [req.userId];
  let sql = `SELECT p.*, (SELECT ma."storageKey" FROM "VideoGenerationJob" j JOIN "MediaAsset" ma ON ma.id = j."resultAssetId" WHERE j."projectId" = p.id AND j.status='completed' ORDER BY j."completedAt" DESC LIMIT 1) AS "resultStorageKey"
             FROM "Project" p WHERE p."userId"=$1 AND p."deletedAt" IS NULL`;
  if (search) { params.push(`%${search}%`); sql += ` AND p.title ILIKE $${params.length}`; }
  if (status) { params.push(status); sql += ` AND p.status = $${params.length}`; }
  sql += ' ORDER BY p."updatedAt" DESC';
  const rows = await pool.query(sql, params);
  ok(res, { projects: rows.rows });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  ok(res, { project });
}));

router.patch('/:id', asyncHandler(async (req, res) => {
  await loadOwnedProject(req.userId!, req.params.id);
  const parsed = z.object({ title: z.string().min(1).max(200).optional() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);
  const r = await pool.query('UPDATE "Project" SET title=COALESCE($1,title), "updatedAt"=now() WHERE id=$2 RETURNING *', [parsed.data.title ?? null, req.params.id]);
  ok(res, { project: r.rows[0] });
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  await loadOwnedProject(req.userId!, req.params.id);
  await pool.query('UPDATE "Project" SET "deletedAt"=now() WHERE id=$1', [req.params.id]);
  ok(res, { success: true });
}));

router.post('/:id/duplicate', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  const r = await pool.query(
    `INSERT INTO "Project" (id,"userId",title,type,status,"durationSec",resolution,timeline)
     VALUES (gen_random_uuid(),$1,$2,$3,'draft',$4,$5,$6) RETURNING *`,
    [req.userId, `${project.title} (copy)`, project.type, project.durationSec, project.resolution, project.timeline]
  );
  ok(res, { project: r.rows[0] }, 201);
}));

// ---------------- EDITOR ----------------
router.get('/:id/editor', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  const scenes = await pool.query('SELECT * FROM "VideoScene" WHERE "projectId"=$1 ORDER BY "order" ASC', [project.id]);
  ok(res, { timeline: project.timeline || { tracks: { video: [], text: [], audio: [] } }, scenes: scenes.rows });
}));

router.patch('/:id/editor', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  const parsed = z.object({ timeline: z.any() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Timeline payload is required.');
  await pool.query('UPDATE "Project" SET timeline=$1, "updatedAt"=now() WHERE id=$2', [JSON.stringify(parsed.data.timeline), project.id]);
  ok(res, { success: true });
}));

router.post('/:id/render', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  const r = await pool.query(
    `INSERT INTO "VideoExport" (id,"projectId",status,resolution) VALUES (gen_random_uuid(),$1,'queued',$2) RETURNING *`,
    [project.id, project.resolution]
  );
  // Minimal real implementation: re-uses the project's already-rendered asset as the "export"
  // rather than a full multi-layer FFmpeg compositor (out of scope for this build — see docs/api.md).
  const latestAsset = await pool.query(
    `SELECT ma.* FROM "VideoGenerationJob" j JOIN "MediaAsset" ma ON ma.id=j."resultAssetId" WHERE j."projectId"=$1 AND j.status='completed' ORDER BY j."completedAt" DESC LIMIT 1`,
    [project.id]
  );
  if (latestAsset.rows[0]) {
    await pool.query('UPDATE "VideoExport" SET status=$1, "storageKey"=$2, "completedAt"=now() WHERE id=$3', ['completed', latestAsset.rows[0].storageKey, r.rows[0].id]);
  } else {
    await pool.query('UPDATE "VideoExport" SET status=$1 WHERE id=$2', ['failed', r.rows[0].id]);
  }
  const final = await pool.query('SELECT * FROM "VideoExport" WHERE id=$1', [r.rows[0].id]);
  ok(res, { export: final.rows[0] }, 201);
}));

router.get('/:id/exports', asyncHandler(async (req, res) => {
  const project = await loadOwnedProject(req.userId!, req.params.id);
  const rows = await pool.query('SELECT * FROM "VideoExport" WHERE "projectId"=$1 ORDER BY "createdAt" DESC', [project.id]);
  ok(res, { exports: rows.rows });
}));

export default router;
