import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import pinoHttp from 'pino-http';

import { config } from './lib/config';
import { logger } from './lib/logger';
import { requestId, errorHandler, notFoundHandler } from './middleware';

import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import creditRoutes from './routes/credits';
import planRoutes from './routes/plans';
import dashboardRoutes from './routes/dashboard';
import projectRoutes from './routes/projects';
import generationRoutes from './routes/generations';
import assetRoutes from './routes/assets';
import libraryRoutes from './routes/library';
import billingRoutes from './routes/billing';
import notificationRoutes from './routes/notifications';
import fileRoutes from './routes/files';

const app = express();

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: config.frontendUrl, credentials: true }));
app.use(cookieParser());
app.use(express.json({ limit: '2mb' }));
app.use(requestId);
app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/api/health' } }));

const globalLimiter = rateLimit({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.max, standardHeaders: true, legacyHeaders: false });
app.use('/api', globalLimiter);

app.get('/api/health', (_req, res) => res.json({ success: true, data: { status: 'ok', time: new Date().toISOString() } }));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/credits', creditRoutes);
app.use('/api/plans', planRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/generations', generationRoutes);
app.use('/api/assets', assetRoutes);
app.use('/api', libraryRoutes); // exposes /api/templates, /api/avatars, /api/voices
app.use('/api/billing', billingRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/files', fileRoutes);

app.use('/api', notFoundHandler);
app.use(errorHandler);

export default app;
