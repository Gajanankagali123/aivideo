import { Router } from 'express';
import multer from 'multer';
import { v4 as uuid } from 'uuid';
import { pool } from '../lib/db';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth, optionalAuth } from '../middleware';
import { storage } from '../lib/storage';

const router = Router();
const upload = multer({ limits: { fileSize: 8 * 1024 * 1024 } });

// ---------------- TEMPLATES (public) ----------------
router.get('/templates', optionalAuth, asyncHandler(async (req, res) => {
  const category = req.query.category as string | undefined;
  const params: any[] = [];
  let sql = 'SELECT * FROM "Template"';
  if (category && category !== 'All') { params.push(category); sql += ` WHERE category=$${params.length}`; }
  sql += ' ORDER BY "createdAt" ASC';
  const rows = await pool.query(sql, params);
  ok(res, { templates: rows.rows });
}));

router.post('/templates/:id/use', requireAuth, asyncHandler(async (req, res) => {
  const r = await pool.query('SELECT * FROM "Template" WHERE id=$1', [req.params.id]);
  if (!r.rows[0]) throw new ApiError(404, 'NOT_FOUND', 'Template not found.');
  ok(res, { prefill: r.rows[0].prefill });
}));

// ---------------- AVATARS ----------------
router.get('/avatars', requireAuth, asyncHandler(async (req, res) => {
  const rows = await pool.query('SELECT * FROM "Avatar" WHERE "userId" IS NULL OR "userId"=$1 ORDER BY "isCustom" ASC, "createdAt" ASC', [req.userId]);
  ok(res, { avatars: rows.rows.map((a: any) => ({ ...a, url: a.storageKey ? storage.getPublicUrl(a.storageKey) : null })) });
}));

router.post('/avatars/custom', requireAuth, upload.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'VALIDATION_ERROR', 'An image file is required.');
  if (!req.file.mimetype.startsWith('image/')) throw new ApiError(400, 'VALIDATION_ERROR', 'Uploaded file must be an image.');
  const storageKey = `avatars/${req.userId}/${uuid()}-${req.file.originalname}`;
  await storage.put(storageKey, req.file.buffer);
  const name = (req.body?.name as string) || 'Custom Avatar';
  const r = await pool.query(
    `INSERT INTO "Avatar" (id,"userId",name,"isCustom","storageKey") VALUES (gen_random_uuid(),$1,$2,true,$3) RETURNING *`,
    [req.userId, name, storageKey]
  );
  ok(res, { avatar: { ...r.rows[0], url: storage.getPublicUrl(storageKey) } }, 201);
}));

// ---------------- VOICES ----------------
router.get('/voices', requireAuth, asyncHandler(async (_req, res) => {
  const rows = await pool.query('SELECT * FROM "Voice" ORDER BY name ASC');
  ok(res, { voices: rows.rows.map((v: any) => ({ ...v, previewUrl: v.sampleKey ? storage.getPublicUrl(v.sampleKey) : null })) });
}));

router.get('/voices/:id/preview', requireAuth, asyncHandler(async (req, res) => {
  const r = await pool.query('SELECT * FROM "Voice" WHERE id=$1', [req.params.id]);
  const voice = r.rows[0];
  if (!voice) throw new ApiError(404, 'NOT_FOUND', 'Voice not found.');
  if (!voice.sampleKey) throw new ApiError(503, 'SAMPLE_NOT_AVAILABLE', 'No preview sample generated for this voice yet. Seed samples with npm run seed:samples.');
  ok(res, { url: storage.getPublicUrl(voice.sampleKey) });
}));

export default router;
