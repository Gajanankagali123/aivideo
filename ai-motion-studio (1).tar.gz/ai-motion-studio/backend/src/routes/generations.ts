import { Router } from 'express';
import { z } from 'zod';
import multer from 'multer';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import { createGenerationJob, getJobStatus, cancelJob } from '../services/generationService';
import { storage } from '../lib/storage';
import { pool } from '../lib/db';
import { v4 as uuid } from 'uuid';

const router = Router();
router.use(requireAuth);

const upload = multer({ limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB, matches frontend copy

const DURATIONS = [5, 10, 15, 30];
function parseDuration(v: any): number {
  const n = parseInt(String(v).replace(/[^0-9]/g, ''), 10);
  return DURATIONS.includes(n) ? n : 10;
}

// ---------------- TEXT TO VIDEO ----------------
const textSchema = z.object({
  prompt: z.string().min(3).max(2000),
  style: z.string().default('Cinematic'),
  aspectRatio: z.string().default('16:9'),
  duration: z.union([z.string(), z.number()]).default(10),
  resolution: z.string().default('1080p'),
  cameraMovement: z.string().optional(),
  visualStyle: z.string().optional(),
  motionStrength: z.number().min(0).max(100).optional(),
  creativity: z.number().min(0).max(100).optional(),
  projectTitle: z.string().optional(),
});

router.post('/text-to-video', asyncHandler(async (req, res) => {
  const parsed = textSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your generation settings.', parsed.error.issues);
  const d = parsed.data;
  const durationSec = parseDuration(d.duration);

  const result = await createGenerationJob({
    userId: req.userId!,
    type: 'text-to-video',
    title: d.projectTitle || d.prompt.slice(0, 60),
    durationSec,
    resolution: d.resolution,
    input: d,
  });
  ok(res, result, 201);
}));

// ---------------- IMAGE TO VIDEO ----------------
router.post('/image-to-video', upload.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'VALIDATION_ERROR', 'An image file is required.');
  if (!req.file.mimetype.startsWith('image/')) throw new ApiError(400, 'VALIDATION_ERROR', 'Uploaded file must be an image.');

  const bodySchema = z.object({
    motionPrompt: z.string().max(2000).optional(),
    cameraMovement: z.string().optional(),
    duration: z.union([z.string(), z.number()]).default(10),
  });
  const parsed = bodySchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your generation settings.', parsed.error.issues);
  const durationSec = parseDuration(parsed.data.duration);

  const storageKey = `uploads/${req.userId}/${uuid()}-${req.file.originalname}`;
  await storage.put(storageKey, req.file.buffer);
  const assetRes = await pool.query(
    `INSERT INTO "MediaAsset" (id,"userId",type,filename,"storageKey","mimeType","sizeBytes") VALUES (gen_random_uuid(),$1,'image',$2,$3,$4,$5) RETURNING *`,
    [req.userId, req.file.originalname, storageKey, req.file.mimetype, req.file.size]
  );

  const result = await createGenerationJob({
    userId: req.userId!,
    type: 'image-to-video',
    title: parsed.data.motionPrompt?.slice(0, 60) || 'Image to Video',
    durationSec,
    resolution: '1080p',
    input: { ...parsed.data, sourceAssetId: assetRes.rows[0].id, sourceStorageKey: storageKey },
  });
  ok(res, result, 201);
}));

// ---------------- SCRIPT TO VIDEO ----------------
const scriptSchema = z.object({
  title: z.string().min(1).max(200),
  script: z.string().min(3).max(20000),
  voiceStyle: z.string().optional(),
  visualStyle: z.string().optional(),
  music: z.string().optional(),
  subtitleStyle: z.string().optional(),
});

router.post('/script-to-video', asyncHandler(async (req, res) => {
  const parsed = scriptSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your script and settings.', parsed.error.issues);
  const d = parsed.data;

  const result = await createGenerationJob({
    userId: req.userId!,
    type: 'script-to-video',
    title: d.title,
    durationSec: 30,
    resolution: '1080p',
    input: d,
  });

  // Naive scene split: one scene per paragraph, matches "AI automatically generates scenes" requirement.
  const paragraphs = d.script.split(/\n{2,}|\r\n{2,}/).map((p) => p.trim()).filter(Boolean);
  for (let i = 0; i < paragraphs.length; i++) {
    await pool.query(
      `INSERT INTO "VideoScene" (id,"projectId","order",text,"durationSec") VALUES (gen_random_uuid(),$1,$2,$3,5)`,
      [result.projectId, i, paragraphs[i]]
    );
  }

  ok(res, result, 201);
}));

// ---------------- AVATAR VIDEO ----------------
const avatarSchema = z.object({
  avatarId: z.string().uuid(),
  script: z.string().min(1).max(5000),
  language: z.string().optional(),
  voiceId: z.string().uuid().optional(),
});

router.post('/avatar-video', asyncHandler(async (req, res) => {
  const parsed = avatarSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your avatar settings.', parsed.error.issues);
  const avatarRes = await pool.query('SELECT * FROM "Avatar" WHERE id=$1', [parsed.data.avatarId]);
  const avatar = avatarRes.rows[0];
  if (!avatar) throw new ApiError(404, 'NOT_FOUND', 'Avatar not found.');

  const result = await createGenerationJob({
    userId: req.userId!,
    type: 'avatar-video',
    title: `${avatar.name} — Avatar Video`,
    durationSec: 10,
    resolution: '1080p',
    input: { ...parsed.data, avatarName: avatar.name },
  });
  ok(res, result, 201);
}));

// ---------------- VOICEOVER ----------------
const voiceoverSchema = z.object({
  text: z.string().min(1).max(5000),
  language: z.string().optional(),
  accent: z.string().optional(),
  speed: z.number().min(0).max(100).optional(),
  pitch: z.number().min(0).max(100).optional(),
  emotion: z.string().optional(),
  voiceId: z.string().uuid().optional(),
});

router.post('/voiceover', asyncHandler(async (req, res) => {
  const parsed = voiceoverSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your voiceover settings.', parsed.error.issues);

  let voiceName: string | undefined;
  if (parsed.data.voiceId) {
    const v = await pool.query('SELECT name FROM "Voice" WHERE id=$1', [parsed.data.voiceId]);
    voiceName = v.rows[0]?.name;
  }

  const result = await createGenerationJob({
    userId: req.userId!,
    type: 'voiceover',
    title: `Voiceover — ${parsed.data.text.slice(0, 40)}`,
    durationSec: 10,
    resolution: '1080p',
    input: { ...parsed.data, voiceName },
  });
  ok(res, result, 201);
}));

// ---------------- JOB STATUS / CANCEL ----------------
router.get('/jobs/:id', asyncHandler(async (req, res) => {
  const job = await getJobStatus(req.userId!, req.params.id);
  ok(res, {
    id: job.id, status: job.status, stage: job.stage, progress: job.progress,
    resultAssetId: job.resultAssetId, error: job.error, projectId: job.projectId,
  });
}));

router.post('/jobs/:id/cancel', asyncHandler(async (req, res) => {
  const result = await cancelJob(req.userId!, req.params.id);
  ok(res, result);
}));

export default router;
