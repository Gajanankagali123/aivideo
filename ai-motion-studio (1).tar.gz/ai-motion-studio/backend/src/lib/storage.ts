import fs from 'fs';
import path from 'path';
import { config } from './config';

/**
 * Storage abstraction. STORAGE_DRIVER=local writes to disk (this build).
 * To go to production, implement an S3Storage class with the same interface
 * (put/getPath/getSignedUrl/delete) using STORAGE_ENDPOINT/BUCKET/KEYS from .env
 * and switch STORAGE_DRIVER=s3 — no route code needs to change.
 */
export interface StorageDriver {
  put(key: string, data: Buffer): Promise<void>;
  getAbsolutePath(key: string): string;
  getPublicUrl(key: string): string;
  delete(key: string): Promise<void>;
  exists(key: string): boolean;
}

class LocalStorage implements StorageDriver {
  private dir: string;
  constructor(dir: string) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
  }
  async put(key: string, data: Buffer) {
    const full = this.getAbsolutePath(key);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, data);
  }
  getAbsolutePath(key: string) {
    return path.join(this.dir, key);
  }
  getPublicUrl(key: string) {
    return `${config.apiUrl}/api/files/${encodeURIComponent(key)}`;
  }
  async delete(key: string) {
    const full = this.getAbsolutePath(key);
    if (fs.existsSync(full)) fs.unlinkSync(full);
  }
  exists(key: string) {
    return fs.existsSync(this.getAbsolutePath(key));
  }
}

// Swap point: if (config.storage.driver === 's3') export new S3Storage(...)
export const storage: StorageDriver = new LocalStorage(config.storage.localDir);
