import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app';

function uniqueEmail() {
  return `credits-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
}

async function registeredAgent() {
  const email = uniqueEmail();
  const agent = request.agent(app);
  await agent.post('/api/auth/register').send({ name: 'Credit Test', email, password: 'password123' });
  return agent;
}

describe('Credit ledger', () => {
  it('grants 15 credits to a new Free-plan user', async () => {
    const agent = await registeredAgent();
    const res = await agent.get('/api/credits/balance');
    expect(res.body.data.balance).toBe(15);
    expect(res.body.data.reserved).toBe(0);
  });

  it('rejects a generation that costs more than the available balance, with no side effects', async () => {
    const agent = await registeredAgent();
    // 30s @ 4K costs far more than the 15-credit Free balance.
    const res = await agent.post('/api/generations/text-to-video').send({
      prompt: 'test prompt for insufficient credits case',
      duration: 30,
      resolution: '4K',
    });
    expect(res.status).toBe(402);
    expect(res.body.error.code).toBe('INSUFFICIENT_CREDITS');

    const balance = await agent.get('/api/credits/balance');
    expect(balance.body.data.balance).toBe(15); // untouched

    const projects = await agent.get('/api/projects');
    expect(projects.body.data.projects.length).toBe(0); // no orphaned project left behind
  });

  it('reserves credits immediately on job creation (balance drops, reserved rises)', async () => {
    const agent = await registeredAgent();
    const res = await agent.post('/api/generations/text-to-video').send({
      prompt: 'a short reservable clip',
      duration: 5,
      resolution: '720p',
    });
    expect(res.status).toBe(201);
    expect(res.body.data.creditsReserved).toBeGreaterThan(0);

    const balance = await agent.get('/api/credits/balance');
    expect(balance.body.data.balance).toBe(15 - res.body.data.creditsReserved);
    expect(balance.body.data.reserved).toBe(res.body.data.creditsReserved);
  });

  it('backend pricing ignores any client-supplied cost field (server is authoritative)', async () => {
    const agent = await registeredAgent();
    const res = await agent.post('/api/generations/text-to-video').send({
      prompt: 'trying to smuggle a cost override',
      duration: 5,
      resolution: '720p',
      creditsReserved: 1, // should be ignored entirely — schema doesn't accept it
      cost: 1,
    });
    expect(res.status).toBe(201);
    expect(res.body.data.creditsReserved).toBe(11); // real computed price for 5s/720p, not 1
  });
});
