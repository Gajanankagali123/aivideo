export interface VideoGenParams {
  prompt: string;
  style?: string;
  aspectRatio?: string;
  durationSec: number;
  resolution: string;
  cameraMovement?: string;
  visualStyle?: string;
  motionStrength?: number;
  creativity?: number;
  sourceImagePath?: string; // for image-to-video
}

export interface VoiceGenParams {
  text: string;
  language?: string;
  accent?: string;
  speed?: number;
  pitch?: number;
  emotion?: string;
  voiceName?: string;
}

export interface AvatarGenParams {
  avatarName: string;
  script: string;
  language?: string;
  voiceName?: string;
}

export interface GenResult {
  /** absolute path to the rendered file on local disk, ready to be moved into storage */
  filePath: string;
  mimeType: string;
  durationSec?: number;
}

export interface VideoProvider {
  name: string;
  isConfigured(): boolean;
  generateVideo(params: VideoGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult>;
}

export interface VoiceProvider {
  name: string;
  isConfigured(): boolean;
  generateVoice(params: VoiceGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult>;
}

export interface AvatarProvider {
  name: string;
  isConfigured(): boolean;
  generateAvatarVideo(params: AvatarGenParams, onProgress: (pct: number, stage: string) => void): Promise<GenResult>;
}
