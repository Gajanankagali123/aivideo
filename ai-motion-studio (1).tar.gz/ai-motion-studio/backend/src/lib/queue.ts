import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { config } from './config';

export const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export interface GenerationJobData {
  jobId: string; // VideoGenerationJob.id (our DB row, source of truth)
}

export const generationQueue = new Queue<GenerationJobData>('video-generation', { connection });
