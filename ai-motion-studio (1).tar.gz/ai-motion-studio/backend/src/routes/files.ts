import { Router } from 'express';
import fs from 'fs';
import { ApiError } from '../lib/response';
import { asyncHandler } from '../middleware';
import { storage } from '../lib/storage';

const router = Router();

// Serves files written by the local storage driver. In production with STORAGE_DRIVER=s3,
// clients use signed URLs returned directly from S3 and this route is unused.
router.get('/:key(*)', asyncHandler(async (req, res) => {
  const key = decodeURIComponent(req.params.key);
  if (key.includes('..')) throw new ApiError(400, 'INVALID_KEY', 'Invalid file key.');
  if (!storage.exists(key)) throw new ApiError(404, 'NOT_FOUND', 'File not found.');
  const full = storage.getAbsolutePath(key);
  fs.createReadStream(full).pipe(res);
}));

export default router;
