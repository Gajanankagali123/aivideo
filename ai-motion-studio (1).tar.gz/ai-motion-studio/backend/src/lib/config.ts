import dotenv from 'dotenv';
import path from 'path';
dotenv.config();

function req(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined) throw new Error(`Missing required env var: ${name}`);
  return v;
}

export const config = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '4000', 10),
  apiUrl: req('API_URL', 'http://localhost:4000'),
  frontendUrl: req('FRONTEND_URL', 'http://localhost:8080'),

  db: { url: req('DATABASE_URL') },
  redisUrl: req('REDIS_URL', 'redis://localhost:6379'),

  jwt: {
    accessSecret: req('JWT_ACCESS_SECRET'),
    refreshSecret: req('JWT_REFRESH_SECRET'),
    accessTtl: process.env.JWT_ACCESS_TTL || '15m',
    refreshTtlDays: 30,
  },
  cookieSecure: process.env.COOKIE_SECURE === 'true',

  storage: {
    driver: process.env.STORAGE_DRIVER || 'local',
    localDir: path.resolve(process.env.STORAGE_LOCAL_DIR || './storage'),
    endpoint: process.env.STORAGE_ENDPOINT || '',
    bucket: process.env.STORAGE_BUCKET || '',
    accessKey: process.env.STORAGE_ACCESS_KEY || '',
    secretKey: process.env.STORAGE_SECRET_KEY || '',
  },

  providers: {
    video: { name: process.env.VIDEO_PROVIDER || 'mock', apiKey: process.env.VIDEO_PROVIDER_API_KEY || '' },
    voice: { name: process.env.VOICE_PROVIDER || 'mock', apiKey: process.env.VOICE_PROVIDER_API_KEY || '' },
    avatar: { name: process.env.AVATAR_PROVIDER || 'mock', apiKey: process.env.AVATAR_PROVIDER_API_KEY || '' },
  },

  payments: {
    provider: process.env.PAYMENT_PROVIDER || 'mock',
    secret: process.env.PAYMENT_PROVIDER_SECRET || '',
    webhookSecret: process.env.PAYMENT_WEBHOOK_SECRET || '',
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10),
    max: parseInt(process.env.RATE_LIMIT_MAX || '120', 10),
  },
};
