import { Router } from 'express';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { v4 as uuid } from 'uuid';
import { pool, withTransaction } from '../lib/db';
import { ok, ApiError, fail } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import {
  hashPassword, verifyPassword, signAccessToken, signRefreshToken, verifyRefreshToken,
  ACCESS_COOKIE, REFRESH_COOKIE, cookieOptions,
} from '../lib/auth';

const router = Router();

const loginLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 15, standardHeaders: true, legacyHeaders: false });

function setAuthCookies(res: any, userId: string, email: string) {
  const access = signAccessToken({ sub: userId, email });
  const refresh = signRefreshToken({ sub: userId, email });
  res.cookie(ACCESS_COOKIE, access, cookieOptions(15 * 60 * 1000));
  res.cookie(REFRESH_COOKIE, refresh, cookieOptions(30 * 24 * 60 * 60 * 1000));
  return refresh;
}

function publicUser(u: any) {
  return { id: u.id, name: u.name, email: u.email, emailVerified: !!u.emailVerifiedAt, createdAt: u.createdAt };
}

// ---------------- REGISTER ----------------
const registerSchema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(200),
});

router.post('/register', asyncHandler(async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);
  const { name, email, password } = parsed.data;

  const existing = await pool.query('SELECT id FROM "User" WHERE email=$1', [email.toLowerCase()]);
  if (existing.rows[0]) throw new ApiError(409, 'EMAIL_TAKEN', 'An account with this email already exists.');

  const passwordHash = await hashPassword(password);

  const user = await withTransaction(async (client) => {
    const userRes = await client.query(
      `INSERT INTO "User" (id,name,email,"passwordHash") VALUES (gen_random_uuid(),$1,$2,$3) RETURNING *`,
      [name, email.toLowerCase(), passwordHash]
    );
    const user = userRes.rows[0];

    const freePlan = await client.query(`SELECT * FROM "Plan" WHERE key='free'`);
    if (!freePlan.rows[0]) throw new ApiError(500, 'PLANS_NOT_SEEDED', 'Plans have not been seeded. Run npm run seed.');
    const plan = freePlan.rows[0];

    await client.query(
      `INSERT INTO "Subscription" (id,"userId","planId",status,"currentPeriodEnd") VALUES (gen_random_uuid(),$1,$2,'active', now() + interval '30 days')`,
      [user.id, plan.id]
    );
    await client.query(
      `INSERT INTO "CreditWallet" (id,"userId",balance,reserved) VALUES (gen_random_uuid(),$1,$2,0)`,
      [user.id, plan.monthlyCredits]
    );
    await client.query(`INSERT INTO "CreditTransaction" (id,"userId",type,amount,reason,"balanceAfter") VALUES (gen_random_uuid(),$1,'grant',$2,'Signup bonus (Free plan)',$2)`, [user.id, plan.monthlyCredits]);
    await client.query(`INSERT INTO "UserSettings" (id,"userId") VALUES (gen_random_uuid(),$1)`, [user.id]);

    return user;
  });

  const refresh = setAuthCookies(res, user.id, user.email);
  await pool.query(
    `INSERT INTO "Session" (id,"userId","refreshToken","userAgent",ip,"expiresAt") VALUES (gen_random_uuid(),$1,$2,$3,$4, now() + interval '30 days')`,
    [user.id, refresh, req.headers['user-agent'] || null, req.ip]
  );

  ok(res, { user: publicUser(user) }, 201);
}));

// ---------------- LOGIN ----------------
const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

router.post('/login', loginLimiter, asyncHandler(async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Please check your details.', parsed.error.issues);
  const { email, password } = parsed.data;

  const userRes = await pool.query('SELECT * FROM "User" WHERE email=$1 AND "deletedAt" IS NULL', [email.toLowerCase()]);
  const user = userRes.rows[0];
  if (!user) throw new ApiError(401, 'INVALID_CREDENTIALS', 'Incorrect email or password.');

  const validPw = await verifyPassword(password, user.passwordHash);
  if (!validPw) throw new ApiError(401, 'INVALID_CREDENTIALS', 'Incorrect email or password.');

  const refresh = setAuthCookies(res, user.id, user.email);
  await pool.query(
    `INSERT INTO "Session" (id,"userId","refreshToken","userAgent",ip,"expiresAt") VALUES (gen_random_uuid(),$1,$2,$3,$4, now() + interval '30 days')`,
    [user.id, refresh, req.headers['user-agent'] || null, req.ip]
  );

  ok(res, { user: publicUser(user) });
}));

// ---------------- LOGOUT ----------------
router.post('/logout', asyncHandler(async (req, res) => {
  const refresh = req.cookies?.[REFRESH_COOKIE];
  if (refresh) await pool.query('UPDATE "Session" SET "revokedAt"=now() WHERE "refreshToken"=$1', [refresh]);
  res.clearCookie(ACCESS_COOKIE, { path: '/' });
  res.clearCookie(REFRESH_COOKIE, { path: '/' });
  ok(res, { success: true });
}));

// ---------------- REFRESH ----------------
router.post('/refresh', asyncHandler(async (req, res) => {
  const refresh = req.cookies?.[REFRESH_COOKIE];
  if (!refresh) throw new ApiError(401, 'UNAUTHENTICATED', 'No session found.');

  let payload;
  try {
    payload = verifyRefreshToken(refresh);
  } catch {
    throw new ApiError(401, 'UNAUTHENTICATED', 'Session expired. Please log in again.');
  }

  const sessionRes = await pool.query('SELECT * FROM "Session" WHERE "refreshToken"=$1', [refresh]);
  const session = sessionRes.rows[0];
  if (!session || session.revokedAt || new Date(session.expiresAt) < new Date()) {
    throw new ApiError(401, 'UNAUTHENTICATED', 'Session expired. Please log in again.');
  }

  const access = signAccessToken({ sub: payload.sub, email: payload.email });
  res.cookie(ACCESS_COOKIE, access, cookieOptions(15 * 60 * 1000));
  ok(res, { success: true });
}));

// ---------------- ME ----------------
router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const userRes = await pool.query('SELECT * FROM "User" WHERE id=$1 AND "deletedAt" IS NULL', [req.userId]);
  const user = userRes.rows[0];
  if (!user) throw new ApiError(401, 'UNAUTHENTICATED', 'Account not found.');
  ok(res, { user: publicUser(user) });
}));

// ---------------- FORGOT PASSWORD ----------------
router.post('/forgot-password', asyncHandler(async (req, res) => {
  const parsed = z.object({ email: z.string().email() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Enter a valid email.');
  const userRes = await pool.query('SELECT * FROM "User" WHERE email=$1', [parsed.data.email.toLowerCase()]);
  const user = userRes.rows[0];
  // Always return success to avoid leaking which emails are registered.
  if (user) {
    const token = uuid() + uuid();
    await pool.query(
      `INSERT INTO "PasswordResetToken" (id,"userId",token,"expiresAt") VALUES (gen_random_uuid(),$1,$2, now() + interval '1 hour')`,
      [user.id, token]
    );
    // In production this token is emailed, not returned. Dev-mode exposes it so the flow is testable end-to-end.
    ok(res, { success: true, devResetToken: process.env.NODE_ENV !== 'production' ? token : undefined });
    return;
  }
  ok(res, { success: true });
}));

// ---------------- RESET PASSWORD ----------------
router.post('/reset-password', asyncHandler(async (req, res) => {
  const parsed = z.object({ token: z.string(), password: z.string().min(8) }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Invalid reset request.');
  const tokenRes = await pool.query('SELECT * FROM "PasswordResetToken" WHERE token=$1', [parsed.data.token]);
  const t = tokenRes.rows[0];
  if (!t || t.usedAt || new Date(t.expiresAt) < new Date()) {
    throw new ApiError(400, 'INVALID_TOKEN', 'This reset link is invalid or has expired.');
  }
  const hash = await hashPassword(parsed.data.password);
  await pool.query('UPDATE "User" SET "passwordHash"=$1, "updatedAt"=now() WHERE id=$2', [hash, t.userId]);
  await pool.query('UPDATE "PasswordResetToken" SET "usedAt"=now() WHERE id=$1', [t.id]);
  await pool.query('UPDATE "Session" SET "revokedAt"=now() WHERE "userId"=$1 AND "revokedAt" IS NULL', [t.userId]);
  ok(res, { success: true });
}));

// ---------------- VERIFY EMAIL (architecture only; token issuance happens at signup in a full build) ----------------
router.post('/verify-email', asyncHandler(async (req, res) => {
  const parsed = z.object({ token: z.string() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'Invalid verification request.');
  const tokenRes = await pool.query('SELECT * FROM "EmailVerificationToken" WHERE token=$1', [parsed.data.token]);
  const t = tokenRes.rows[0];
  if (!t || t.usedAt || new Date(t.expiresAt) < new Date()) throw new ApiError(400, 'INVALID_TOKEN', 'This verification link is invalid or has expired.');
  await pool.query('UPDATE "User" SET "emailVerifiedAt"=now() WHERE id=$1', [t.userId]);
  await pool.query('UPDATE "EmailVerificationToken" SET "usedAt"=now() WHERE id=$1', [t.id]);
  ok(res, { success: true });
}));

export default router;
