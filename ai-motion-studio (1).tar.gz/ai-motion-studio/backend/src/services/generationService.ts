import { pool, withTransaction } from '../lib/db';
import { generationQueue } from '../lib/queue';
import { calculateGenerationCost, reserveCredits, refundCredits } from './creditService';
import { ApiError } from '../lib/response';

export type GenerationType = 'text-to-video' | 'image-to-video' | 'script-to-video' | 'avatar-video' | 'voiceover';

interface CreateJobArgs {
  userId: string;
  type: GenerationType;
  title: string;
  durationSec: number;
  resolution: string;
  input: Record<string, any>;
}

/**
 * Full flow per spec: validate -> price -> check+reserve credits -> create Project ->
 * create VideoGenerationJob -> enqueue BullMQ -> return job id. All DB writes in one transaction;
 * credits are only reserved after the project/job rows exist so we always have somewhere to refund against.
 */
export async function createGenerationJob(args: CreateJobArgs) {
  const cost = calculateGenerationCost({ type: args.type, durationSec: args.durationSec, resolution: args.resolution });

  const { project, job } = await withTransaction(async (client) => {
    const projectRes = await client.query(
      `INSERT INTO "Project" (id,"userId",title,type,status,"durationSec",resolution)
       VALUES (gen_random_uuid(),$1,$2,$3,'queued',$4,$5) RETURNING *`,
      [args.userId, args.title, args.type, args.durationSec, args.resolution]
    );
    const project = projectRes.rows[0];

    const jobRes = await client.query(
      `INSERT INTO "VideoGenerationJob" (id,"userId","projectId",type,status,stage,progress,input,"creditsReserved")
       VALUES (gen_random_uuid(),$1,$2,$3,'queued','QUEUED',0,$4,$5) RETURNING *`,
      [args.userId, project.id, args.type, JSON.stringify(args.input), cost]
    );
    const job = jobRes.rows[0];
    return { project, job };
  });

  // Reserve credits now that we have a jobId to attach the ledger entry to.
  try {
    await reserveCredits(args.userId, cost, `Generation job ${job.id} (${args.type})`, job.id);
  } catch (err) {
    // Roll back the project/job we just created so we don't leave orphaned "queued" rows.
    await pool.query('DELETE FROM "VideoGenerationJob" WHERE id=$1', [job.id]);
    await pool.query('DELETE FROM "Project" WHERE id=$1', [project.id]);
    throw err;
  }

  await generationQueue.add('generate', { jobId: job.id }, { removeOnComplete: 100, removeOnFail: 100 });

  return { jobId: job.id, projectId: project.id, status: 'queued', creditsReserved: cost };
}

export async function getJobStatus(userId: string, jobId: string) {
  const res = await pool.query('SELECT * FROM "VideoGenerationJob" WHERE id=$1', [jobId]);
  const job = res.rows[0];
  if (!job) throw new ApiError(404, 'NOT_FOUND', 'Generation job not found.');
  if (job.userId !== userId) throw new ApiError(403, 'FORBIDDEN', 'You do not have access to this job.');
  return job;
}

export async function cancelJob(userId: string, jobId: string) {
  const job = await getJobStatus(userId, jobId);
  if (job.status !== 'queued' && job.status !== 'processing') {
    throw new ApiError(400, 'INVALID_STATE', `Job is already ${job.status}.`);
  }
  await pool.query('UPDATE "VideoGenerationJob" SET status=$1, stage=$2 WHERE id=$3', ['canceled', 'CANCELED', jobId]);
  await refundCredits(userId, job.creditsReserved, `Job ${jobId} canceled by user`, jobId);
  await pool.query('UPDATE "Project" SET status=$1 WHERE id=$2', ['failed', job.projectId]);
  return { success: true };
}
