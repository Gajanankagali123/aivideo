import type { PoolClient } from 'pg';
import { pool, withTransaction } from '../lib/db';
import { ApiError } from '../lib/response';

/**
 * Credit ledger rules (see docs/api.md#credits):
 * - wallet.balance  = credits the user can still spend
 * - wallet.reserved = credits held against in-flight jobs (already subtracted from balance)
 * - Every mutation writes a CreditTransaction row. Nothing changes balance without a row.
 * - All mutations run inside a single DB transaction using SELECT ... FOR UPDATE to prevent races.
 */

export async function getWallet(userId: string) {
  const res = await pool.query('SELECT * FROM "CreditWallet" WHERE "userId" = $1', [userId]);
  return res.rows[0];
}

async function lockWallet(client: PoolClient, userId: string) {
  const res = await client.query('SELECT * FROM "CreditWallet" WHERE "userId" = $1 FOR UPDATE', [userId]);
  if (!res.rows[0]) throw new ApiError(500, 'WALLET_MISSING', 'No credit wallet found for user.');
  return res.rows[0];
}

async function writeTx(client: PoolClient, userId: string, type: string, amount: number, reason: string, balanceAfter: number, jobId?: string) {
  await client.query(
    `INSERT INTO "CreditTransaction" (id, "userId", type, amount, reason, "jobId", "balanceAfter")
     VALUES (gen_random_uuid(), $1,$2,$3,$4,$5,$6)`,
    [userId, type, amount, reason, jobId ?? null, balanceAfter]
  );
}

/** Reserve credits for a new job. Throws INSUFFICIENT_CREDITS if balance too low. Atomic. */
export async function reserveCredits(userId: string, amount: number, reason: string, jobId?: string) {
  return withTransaction(async (client) => {
    const wallet = await lockWallet(client, userId);
    if (wallet.balance < amount) {
      throw new ApiError(402, 'INSUFFICIENT_CREDITS', `This generation costs ${amount} credits, you have ${wallet.balance}.`);
    }
    const newBalance = wallet.balance - amount;
    const newReserved = wallet.reserved + amount;
    await client.query('UPDATE "CreditWallet" SET balance=$1, reserved=$2, "updatedAt"=now() WHERE "userId"=$3', [newBalance, newReserved, userId]);
    await writeTx(client, userId, 'reserve', -amount, reason, newBalance, jobId);
    return { balance: newBalance, reserved: newReserved };
  });
}

/** Commit previously-reserved credits once a job completes successfully (removes from reserved permanently). */
export async function commitCredits(userId: string, amount: number, reason: string, jobId?: string) {
  return withTransaction(async (client) => {
    const wallet = await lockWallet(client, userId);
    const newReserved = Math.max(0, wallet.reserved - amount);
    await client.query('UPDATE "CreditWallet" SET reserved=$1, "updatedAt"=now() WHERE "userId"=$2', [newReserved, userId]);
    await writeTx(client, userId, 'commit', 0, reason, wallet.balance, jobId);
    return { balance: wallet.balance, reserved: newReserved };
  });
}

/** Refund reserved credits back to spendable balance (job failed/canceled). Atomic. */
export async function refundCredits(userId: string, amount: number, reason: string, jobId?: string) {
  return withTransaction(async (client) => {
    const wallet = await lockWallet(client, userId);
    const newReserved = Math.max(0, wallet.reserved - amount);
    const newBalance = wallet.balance + amount;
    await client.query('UPDATE "CreditWallet" SET balance=$1, reserved=$2, "updatedAt"=now() WHERE "userId"=$3', [newBalance, newReserved, userId]);
    await writeTx(client, userId, 'refund', amount, reason, newBalance, jobId);
    return { balance: newBalance, reserved: newReserved };
  });
}

/** Add credits (monthly grant, or purchase / plan upgrade). */
export async function addCredits(userId: string, amount: number, reason: string) {
  return withTransaction(async (client) => {
    const wallet = await lockWallet(client, userId);
    const newBalance = wallet.balance + amount;
    await client.query('UPDATE "CreditWallet" SET balance=$1, "updatedAt"=now() WHERE "userId"=$2', [newBalance, userId]);
    await writeTx(client, userId, 'grant', amount, reason, newBalance);
    return { balance: newBalance };
  });
}

/** Expire unused credits at period rollover (not wired to a cron in this build, but implemented and callable). */
export async function expireCredits(userId: string, amount: number, reason: string) {
  return withTransaction(async (client) => {
    const wallet = await lockWallet(client, userId);
    const newBalance = Math.max(0, wallet.balance - amount);
    await client.query('UPDATE "CreditWallet" SET balance=$1, "updatedAt"=now() WHERE "userId"=$2', [newBalance, userId]);
    await writeTx(client, userId, 'expire', -(wallet.balance - newBalance), reason, newBalance);
    return { balance: newBalance };
  });
}

/**
 * Backend-authoritative pricing. The frontend NEVER supplies a credit cost — this is
 * the only place the number is calculated. See docs/api.md#pricing.
 */
export function calculateGenerationCost(input: {
  type: 'text-to-video' | 'image-to-video' | 'script-to-video' | 'avatar-video' | 'voiceover';
  durationSec?: number;
  resolution?: string;
}): number {
  const durationCredits: Record<number, number> = { 5: 16, 10: 32, 15: 48, 30: 90 };
  let base: number;

  if (input.type === 'voiceover') {
    base = 8;
  } else {
    const dur = input.durationSec ?? 10;
    // nearest supported bucket, rounding up
    const bucket = [5, 10, 15, 30].find((d) => dur <= d) ?? 30;
    base = durationCredits[bucket];
    if (input.type === 'avatar-video') base = Math.round(base * 1.25);
  }

  const res = (input.resolution || '1080p').toLowerCase();
  if (res === '4k') base = Math.round(base * 1.8);
  else if (res === '720p') base = Math.round(base * 0.7);

  return base;
}
