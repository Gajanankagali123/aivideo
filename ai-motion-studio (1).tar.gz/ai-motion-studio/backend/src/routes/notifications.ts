import { Router } from 'express';
import { pool } from '../lib/db';
import { ok } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';

const router = Router();
router.use(requireAuth);

router.get('/', asyncHandler(async (req, res) => {
  const rows = await pool.query('SELECT * FROM "Notification" WHERE "userId"=$1 ORDER BY "createdAt" DESC LIMIT 30', [req.userId]);
  ok(res, { notifications: rows.rows });
}));

router.post('/:id/read', asyncHandler(async (req, res) => {
  await pool.query('UPDATE "Notification" SET "readAt"=now() WHERE id=$1 AND "userId"=$2', [req.params.id, req.userId]);
  ok(res, { success: true });
}));

export default router;
