import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app';

function uniqueEmail() {
  return `test-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
}

describe('Auth', () => {
  it('registers a new user with a starting Free-plan credit grant', async () => {
    const email = uniqueEmail();
    const res = await request(app).post('/api/auth/register').send({ name: 'Jane Doe', email, password: 'password123' });
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.email).toBe(email);
    expect(res.headers['set-cookie']).toBeTruthy();
  });

  it('rejects duplicate email registration', async () => {
    const email = uniqueEmail();
    await request(app).post('/api/auth/register').send({ name: 'A', email, password: 'password123' });
    const res = await request(app).post('/api/auth/register').send({ name: 'B', email, password: 'password123' });
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('EMAIL_TAKEN');
  });

  it('rejects weak/invalid registration payloads', async () => {
    const res = await request(app).post('/api/auth/register').send({ name: '', email: 'not-an-email', password: '123' });
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('logs in with correct credentials and rejects incorrect ones', async () => {
    const email = uniqueEmail();
    await request(app).post('/api/auth/register').send({ name: 'Login Test', email, password: 'password123' });

    const good = await request(app).post('/api/auth/login').send({ email, password: 'password123' });
    expect(good.status).toBe(200);

    const bad = await request(app).post('/api/auth/login').send({ email, password: 'wrongpassword' });
    expect(bad.status).toBe(401);
    expect(bad.body.error.code).toBe('INVALID_CREDENTIALS');
  });

  it('rejects unauthenticated access to protected routes', async () => {
    const res = await request(app).get('/api/dashboard/summary');
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('UNAUTHENTICATED');
  });

  it('me/logout/me round trip', async () => {
    const email = uniqueEmail();
    const agent = request.agent(app);
    await agent.post('/api/auth/register').send({ name: 'Session Test', email, password: 'password123' });

    const me = await agent.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.data.user.email).toBe(email);

    await agent.post('/api/auth/logout');
    const meAfter = await agent.get('/api/auth/me');
    expect(meAfter.status).toBe(401);
  });
});
