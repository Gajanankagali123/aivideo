import { Response } from 'express';

export function ok(res: Response, data: any = {}, status = 200) {
  return res.status(status).json({ success: true, data });
}

export class ApiError extends Error {
  status: number;
  code: string;
  details: any[];
  constructor(status: number, code: string, message: string, details: any[] = []) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function fail(res: Response, err: ApiError) {
  return res.status(err.status).json({
    success: false,
    error: { code: err.code, message: err.message, details: err.details },
  });
}
