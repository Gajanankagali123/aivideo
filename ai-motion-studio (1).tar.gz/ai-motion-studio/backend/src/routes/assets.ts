import { Router } from 'express';
import multer from 'multer';
import { v4 as uuid } from 'uuid';
import { pool } from '../lib/db';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import { storage } from '../lib/storage';

const router = Router();
router.use(requireAuth);

const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 } });
const ALLOWED_MIME = /^(image|video|audio)\//;

router.get('/', asyncHandler(async (req, res) => {
  const type = req.query.type as string | undefined;
  const params: any[] = [req.userId];
  let sql = 'SELECT * FROM "MediaAsset" WHERE "userId"=$1';
  if (type) { params.push(type); sql += ` AND type=$${params.length}`; }
  sql += ' ORDER BY "createdAt" DESC';
  const rows = await pool.query(sql, params);
  ok(res, { assets: rows.rows.map(withUrl) });
}));

router.post('/', upload.single('file'), asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'VALIDATION_ERROR', 'A file is required.');
  if (!ALLOWED_MIME.test(req.file.mimetype)) throw new ApiError(400, 'VALIDATION_ERROR', 'Only image, video, or audio files are allowed.');

  const type = req.file.mimetype.startsWith('image/') ? 'image' : req.file.mimetype.startsWith('video/') ? 'video' : 'audio';
  const storageKey = `assets/${req.userId}/${uuid()}-${req.file.originalname}`;
  await storage.put(storageKey, req.file.buffer);

  const r = await pool.query(
    `INSERT INTO "MediaAsset" (id,"userId",type,filename,"storageKey","mimeType","sizeBytes") VALUES (gen_random_uuid(),$1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.userId, type, req.file.originalname, storageKey, req.file.mimetype, req.file.size]
  );
  ok(res, { asset: withUrl(r.rows[0]) }, 201);
}));

router.get('/:id/download-url', asyncHandler(async (req, res) => {
  const r = await pool.query('SELECT * FROM "MediaAsset" WHERE id=$1', [req.params.id]);
  const asset = r.rows[0];
  if (!asset) throw new ApiError(404, 'NOT_FOUND', 'Asset not found.');
  if (asset.userId !== req.userId) throw new ApiError(403, 'FORBIDDEN', 'You do not have access to this asset.');
  ok(res, { url: storage.getPublicUrl(asset.storageKey), filename: asset.filename });
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  const r = await pool.query('SELECT * FROM "MediaAsset" WHERE id=$1', [req.params.id]);
  const asset = r.rows[0];
  if (!asset) throw new ApiError(404, 'NOT_FOUND', 'Asset not found.');
  if (asset.userId !== req.userId) throw new ApiError(403, 'FORBIDDEN', 'You do not have access to this asset.');
  await storage.delete(asset.storageKey);
  await pool.query('DELETE FROM "MediaAsset" WHERE id=$1', [req.params.id]);
  ok(res, { success: true });
}));

function withUrl(asset: any) {
  return { ...asset, url: storage.getPublicUrl(asset.storageKey) };
}

export default router;
