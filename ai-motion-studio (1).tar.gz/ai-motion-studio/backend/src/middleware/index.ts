import { Request, Response, NextFunction } from 'express';
import { v4 as uuid } from 'uuid';
import { ACCESS_COOKIE, verifyAccessToken } from '../lib/auth';
import { ApiError, fail } from '../lib/response';
import { logger } from '../lib/logger';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      userId?: string;
      userEmail?: string;
      requestId: string;
    }
  }
}

export function requestId(req: Request, res: Response, next: NextFunction) {
  req.requestId = uuid();
  res.setHeader('x-request-id', req.requestId);
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies?.[ACCESS_COOKIE];
  if (!token) return fail(res, new ApiError(401, 'UNAUTHENTICATED', 'Log in to continue.'));
  try {
    const payload = verifyAccessToken(token);
    req.userId = payload.sub;
    req.userEmail = payload.email;
    next();
  } catch {
    return fail(res, new ApiError(401, 'UNAUTHENTICATED', 'Session expired. Please log in again.'));
  }
}

/** Doesn't reject unauthenticated users, just attaches userId if present (used for public+personalized routes) */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const token = req.cookies?.[ACCESS_COOKIE];
  if (token) {
    try {
      const payload = verifyAccessToken(token);
      req.userId = payload.sub;
      req.userEmail = payload.email;
    } catch {
      /* ignore */
    }
  }
  next();
}

export function notFoundHandler(req: Request, res: Response) {
  fail(res, new ApiError(404, 'NOT_FOUND', `No route for ${req.method} ${req.path}`));
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ApiError) {
    if (err.status >= 500) logger.error({ err, requestId: req.requestId }, err.message);
    return fail(res, err);
  }
  logger.error({ err, requestId: req.requestId }, 'Unhandled error');
  return fail(res, new ApiError(500, 'INTERNAL_ERROR', 'Something went wrong. Please try again.'));
}

export function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) {
  return (req: Request, res: Response, next: NextFunction) => fn(req, res, next).catch(next);
}
