import { Router } from 'express';
import { pool } from '../lib/db';
import { ok } from '../lib/response';
import { asyncHandler } from '../middleware';

const router = Router();

router.get('/', asyncHandler(async (_req, res) => {
  const rows = await pool.query('SELECT * FROM "Plan" ORDER BY "priceCents" ASC');
  ok(res, { plans: rows.rows });
}));

export default router;
