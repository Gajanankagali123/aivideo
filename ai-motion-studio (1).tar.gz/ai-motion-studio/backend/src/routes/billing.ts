import { Router } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { pool, withTransaction } from '../lib/db';
import { ok, ApiError } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import { config } from '../lib/config';
import { addCredits } from '../services/creditService';

const router = Router();

/**
 * Payment provider abstraction, same pattern as the AI provider registry:
 * PAYMENT_PROVIDER=mock (default) simulates a checkout + webhook round-trip locally so the
 * whole subscription flow is testable without a live payment account. Swapping in
 * PAYMENT_PROVIDER=stripe with PAYMENT_PROVIDER_SECRET/PAYMENT_WEBHOOK_SECRET set would need
 * a real adapter implemented here — the route contracts and DB writes below don't change.
 */

router.get('/subscription', requireAuth, asyncHandler(async (req, res) => {
  const r = await pool.query(
    `SELECT s.*, p.key AS "planKey", p.name AS "planName", p."monthlyCredits", p."priceCents"
     FROM "Subscription" s JOIN "Plan" p ON p.id=s."planId" WHERE s."userId"=$1`,
    [req.userId]
  );
  ok(res, { subscription: r.rows[0] ?? null });
}));

router.post('/checkout', requireAuth, asyncHandler(async (req, res) => {
  const parsed = z.object({ planId: z.string().uuid() }).safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'VALIDATION_ERROR', 'A valid plan is required.');
  const planRes = await pool.query('SELECT * FROM "Plan" WHERE id=$1', [parsed.data.planId]);
  const plan = planRes.rows[0];
  if (!plan) throw new ApiError(404, 'NOT_FOUND', 'Plan not found.');

  const paymentRes = await pool.query(
    `INSERT INTO "Payment" (id,"userId","planId",provider,"amountCents",currency,status) VALUES (gen_random_uuid(),$1,$2,$3,$4,$5,'pending') RETURNING *`,
    [req.userId, plan.id, config.payments.provider, plan.priceCents, plan.currency]
  );
  const payment = paymentRes.rows[0];

  if (config.payments.provider === 'mock') {
    // Dev-mode only: gives the frontend a same-origin URL that fires the webhook itself,
    // standing in for a hosted checkout page + redirect. Never used when a real provider is configured.
    ok(res, {
      payment,
      devCheckoutUrl: `${config.apiUrl}/api/billing/dev-simulate-payment/${payment.id}`,
      note: 'PAYMENT_PROVIDER=mock: no live payment account configured. This confirms the payment locally instead of redirecting to a real checkout page.',
    }, 201);
    return;
  }

  throw new ApiError(503, 'PROVIDER_NOT_CONFIGURED', `PAYMENT_PROVIDER=${config.payments.provider} has no adapter implemented in this build.`);
}));

// Dev-only helper endpoint: fires the same code path a real webhook would, so the
// end-to-end "pay -> credits granted" flow can be exercised without a live provider.
router.post('/dev-simulate-payment/:paymentId', requireAuth, asyncHandler(async (req, res) => {
  if (config.payments.provider !== 'mock') throw new ApiError(403, 'FORBIDDEN', 'Only available when PAYMENT_PROVIDER=mock.');
  const eventId = `evt_dev_${req.params.paymentId}`;
  const result = await processPaymentEvent(eventId, { paymentId: req.params.paymentId, status: 'succeeded' });
  ok(res, result);
}));

router.post('/cancel', requireAuth, asyncHandler(async (req, res) => {
  const r = await pool.query(
    `UPDATE "Subscription" SET "cancelAtPeriodEnd"=true, "updatedAt"=now() WHERE "userId"=$1 RETURNING *`,
    [req.userId]
  );
  if (!r.rows[0]) throw new ApiError(404, 'NOT_FOUND', 'No active subscription found.');
  ok(res, { subscription: r.rows[0] });
}));

/**
 * Real webhook endpoint. Verifies an HMAC signature against PAYMENT_WEBHOOK_SECRET and is
 * idempotent via the WebhookEvent unique(eventId) constraint — replays are a no-op.
 */
router.post('/webhook', asyncHandler(async (req, res) => {
  const signature = req.headers['x-webhook-signature'] as string | undefined;
  if (config.payments.webhookSecret) {
    const expected = crypto.createHmac('sha256', config.payments.webhookSecret).update(JSON.stringify(req.body)).digest('hex');
    if (signature !== expected) throw new ApiError(400, 'INVALID_SIGNATURE', 'Webhook signature verification failed.');
  }
  const eventId = req.body?.id || req.body?.eventId;
  if (!eventId) throw new ApiError(400, 'VALIDATION_ERROR', 'Webhook payload missing event id.');
  const result = await processPaymentEvent(eventId, req.body);
  ok(res, { received: true, ...result });
}));

async function processPaymentEvent(eventId: string, payload: any) {
  return withTransaction(async (client) => {
    const existing = await client.query('SELECT * FROM "WebhookEvent" WHERE "eventId"=$1', [eventId]);
    if (existing.rows[0]) {
      return { alreadyProcessed: true }; // idempotent replay
    }
    await client.query(
      `INSERT INTO "WebhookEvent" (id,provider,"eventId",payload,"processedAt") VALUES (gen_random_uuid(),$1,$2,$3,now())`,
      [config.payments.provider, eventId, JSON.stringify(payload)]
    );

    if (payload.status !== 'succeeded') return { alreadyProcessed: false, applied: false };

    const paymentRes = await client.query('SELECT * FROM "Payment" WHERE id=$1', [payload.paymentId]);
    const payment = paymentRes.rows[0];
    if (!payment || payment.status === 'succeeded') return { alreadyProcessed: false, applied: false };

    await client.query('UPDATE "Payment" SET status=$1 WHERE id=$2', ['succeeded', payment.id]);

    const plan = (await client.query('SELECT * FROM "Plan" WHERE id=$1', [payment.planId])).rows[0];
    await client.query(
      `INSERT INTO "Subscription" (id,"userId","planId",status,"currentPeriodEnd")
       VALUES (gen_random_uuid(),$1,$2,'active', now() + interval '30 days')
       ON CONFLICT ("userId") DO UPDATE SET "planId"=$2, status='active', "currentPeriodEnd"=now() + interval '30 days', "cancelAtPeriodEnd"=false, "updatedAt"=now()`,
      [payment.userId, plan.id]
    );
    return { alreadyProcessed: false, applied: true, planId: plan.id };
  }).then(async (result: any) => {
    // Credit grant happens via the ledger service outside the row-lock transaction above
    // to reuse its own transaction + audit trail, only if this webhook actually applied a change.
    if (result.applied) {
      const paymentRes = await pool.query('SELECT * FROM "Payment" WHERE id=$1', [payload.paymentId]);
      const plan = (await pool.query('SELECT * FROM "Plan" WHERE id=$1', [paymentRes.rows[0].planId])).rows[0];
      await addCredits(paymentRes.rows[0].userId, plan.monthlyCredits, `Plan upgrade to ${plan.name} confirmed by payment ${paymentRes.rows[0].id}`);
    }
    return result;
  });
}

export default router;
