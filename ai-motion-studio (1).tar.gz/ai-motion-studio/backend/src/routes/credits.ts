import { Router } from 'express';
import { pool } from '../lib/db';
import { ok } from '../lib/response';
import { asyncHandler, requireAuth } from '../middleware';
import { getWallet } from '../services/creditService';

const router = Router();
router.use(requireAuth);

router.get('/balance', asyncHandler(async (req, res) => {
  const wallet = await getWallet(req.userId!);
  const subRes = await pool.query(
    `SELECT p.key, p.name FROM "Subscription" s JOIN "Plan" p ON p.id = s."planId" WHERE s."userId"=$1`,
    [req.userId]
  );
  ok(res, { balance: wallet?.balance ?? 0, reserved: wallet?.reserved ?? 0, plan: subRes.rows[0] ?? null });
}));

router.get('/transactions', asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(String(req.query.limit || '50'), 10), 200);
  const rows = await pool.query(
    `SELECT * FROM "CreditTransaction" WHERE "userId"=$1 ORDER BY "createdAt" DESC LIMIT $2`,
    [req.userId, limit]
  );
  ok(res, { transactions: rows.rows });
}));

export default router;
