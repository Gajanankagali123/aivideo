import app from './app';
import { config } from './lib/config';
import { logger } from './lib/logger';

app.listen(config.port, () => {
  logger.info(`AI Motion Studio API listening on http://localhost:${config.port} (env: ${config.env})`);
});
