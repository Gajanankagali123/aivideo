import { config } from '../lib/config';
import { ApiError } from '../lib/response';
import { MockVideoProvider, MockVoiceProvider, MockAvatarProvider } from './mockProvider';
import { VideoProvider, VoiceProvider, AvatarProvider } from './types';

const mockVideo = new MockVideoProvider();
const mockVoice = new MockVoiceProvider();
const mockAvatar = new MockAvatarProvider();

/**
 * To add a real provider: create RunwayVideoProvider implements VideoProvider in this folder,
 * then add a branch below keyed on config.providers.video.name. Never silently fall back to
 * mock when a non-mock provider is selected but unconfigured — throw instead (see below).
 */
export function getVideoProvider(): VideoProvider {
  const name = config.providers.video.name;
  if (name === 'mock') return mockVideo;
  // Real provider selected but no adapter implemented / no key present.
  if (!config.providers.video.apiKey) {
    throw new ApiError(503, 'PROVIDER_NOT_CONFIGURED', `VIDEO_PROVIDER=${name} but VIDEO_PROVIDER_API_KEY is not set.`);
  }
  throw new ApiError(503, 'PROVIDER_NOT_IMPLEMENTED', `No adapter implemented yet for VIDEO_PROVIDER=${name}.`);
}

export function getVoiceProvider(): VoiceProvider {
  const name = config.providers.voice.name;
  if (name === 'mock') return mockVoice;
  if (!config.providers.voice.apiKey) {
    throw new ApiError(503, 'PROVIDER_NOT_CONFIGURED', `VOICE_PROVIDER=${name} but VOICE_PROVIDER_API_KEY is not set.`);
  }
  throw new ApiError(503, 'PROVIDER_NOT_IMPLEMENTED', `No adapter implemented yet for VOICE_PROVIDER=${name}.`);
}

export function getAvatarProvider(): AvatarProvider {
  const name = config.providers.avatar.name;
  if (name === 'mock') return mockAvatar;
  if (!config.providers.avatar.apiKey) {
    throw new ApiError(503, 'PROVIDER_NOT_CONFIGURED', `AVATAR_PROVIDER=${name} but AVATAR_PROVIDER_API_KEY is not set.`);
  }
  throw new ApiError(503, 'PROVIDER_NOT_IMPLEMENTED', `No adapter implemented yet for AVATAR_PROVIDER=${name}.`);
}
